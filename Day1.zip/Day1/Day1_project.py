print("Welcome to the band name generater.")
city = input("Which city did you grow up in?")
pet = input("What is the name of a pet?")
print("Your band name could be "+city+" "+pet)