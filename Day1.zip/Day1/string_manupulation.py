print("hello world:\nhello world:")
# concatinate
print("Hello"+" "+"rahul")
