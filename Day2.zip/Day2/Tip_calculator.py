print("Welcome to the tip calculator")
total_bill = int(input("What was the total bill?"))
tip = int(input("How much tip would you like to give? 10,12, or 15?"))
person = int(input("How many person to split the bill?"))
ans = (total_bill + (total_bill * (tip/100)))/person
print(f"Each person should pay: ${round(ans,2)}")