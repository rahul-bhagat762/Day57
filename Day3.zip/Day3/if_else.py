# if condition:
#     do this
# else:
#     do this

# water_level = 90
# if water_level > 80:
#     print("Drain Water")

# n = int(input("Enter Your height:"))
# if(n>=120):
#     print("You can ride")
# else:
#     print("You cant ride")


# n = int(input("Enter your number for check:"))
# if n%2==0:
#     print("even")
# else:
#     print("Odd")


# if condition:
#     if another condition:
#         do this
#     else:
#         do this
# else:
#     do this

height = int(input("Enter your height :"))
if height>=120:
    print("You can ride the rollercoaster!")
    age = int(input("What is your age?"))
    if age<12:
        print("please pay $5.")
    elif age>12 and age<=18:
        print("Please pay $7.")
    else:
        print("please pay $12.")
else:
    print("sorry, you have to grow taller before you can ride.")