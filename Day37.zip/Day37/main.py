import requests
from datetime import datetime
Now = datetime.now()
st = str(Now.strftime("%Y%m%d"))

pixela_endpoint = 'https://pixe.la/v1/users'
token = "cajbivkhbcciiva46v8sdv"
username = 'rahul8873'
graph_id = 'graph1'

user_param = {
    'token': "cajbivkhbcciiva46v8sdv",
    'username': 'rahul8873',
    'agreeTermsOfService': 'yes',
    'notMinor':'yes'

}
# response = requests.post(url=pixela_endpoint,json=user_param)
# print(response.text)

graph_endpoint = f'{pixela_endpoint}/{username}/graphs'

graph_configuration = {
    'id': graph_id,
    'name': 'Coding',
    'unit' : 'streaks',
    'type': 'int',
    'color':'ajisai'

}

headers = {
    'X-USER-TOKEN': token
}

response = requests.post(url=graph_endpoint,json=graph_configuration,headers=headers)
print(response.text)


pixel_creation_endpoint = f'{pixela_endpoint}/{username}/graphs/{graph_id}'


pixel_data = {
    "date": st,
    'quantity': input("Enter the number of question you solve today:"),
}

response =  requests.post(url=pixel_creation_endpoint,json=pixel_data,headers=headers)
print(response.text)



# put or update

# pixel_updation_endpoint = f"{pixela_endpoint}/{username}/graphs/{graph_id}"
# pixel_data = {
#     "date": st,
#     'quantity':'15'
# }

# response = requests.put(url=pixel_updation_endpoint,json=pixel_data,headers= headers)
# print(response.text)


# pixel_delete_endpoint = f"{pixela_endpoint}/{username}/graphs/{graph_id}/st"

# response = requests.delete(url=pixel_delete_endpoint,headers=headers)
# print(response.text)
