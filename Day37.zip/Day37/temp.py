from datetime import datetime
Now = datetime.now()

print(type(st))





