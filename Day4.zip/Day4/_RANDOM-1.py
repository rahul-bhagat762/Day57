# import random
# # import my_module
# ranadom_integer = random.randint(1,5)
# print(ranadom_integer)
# # print(my_module.pi)

# random_float = random.random()
# # random_float * 5
# print(random_float*5)

# List
fruits = ['apple','cherry',"pear"]
print(fruits[0])
print(fruits[1])
print(fruits[2])