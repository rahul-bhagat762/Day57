# def greed():
#     print("1")
#     print("2")
#     print("3")

# greed()

# def greed_with_name(name):
#     print(f"hello {name}")
#     print(f"How do you do {name}")


# greed_with_name('sohit')

# function with more then one parameters
def greed_with(name,location):
    print(f"Hello my name is {name}")
    print(f"i live in {location}")

greed_with('sohit','rampur')